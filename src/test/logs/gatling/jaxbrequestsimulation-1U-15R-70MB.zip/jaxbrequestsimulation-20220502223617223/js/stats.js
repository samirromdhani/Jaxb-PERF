var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "60",
        "ok": "38",
        "ko": "22"
    },
    "minResponseTime": {
        "total": "54962",
        "ok": "54962",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60008",
        "ok": "59695",
        "ko": "60008"
    },
    "meanResponseTime": {
        "total": "58538",
        "ok": "57689",
        "ko": "60003"
    },
    "standardDeviation": {
        "total": "1440",
        "ok": "1146",
        "ko": "2"
    },
    "percentiles1": {
        "total": "58749",
        "ok": "57898",
        "ko": "60002"
    },
    "percentiles2": {
        "total": "60001",
        "ok": "58688",
        "ko": "60004"
    },
    "percentiles3": {
        "total": "60005",
        "ok": "59013",
        "ko": "60005"
    },
    "percentiles4": {
        "total": "60006",
        "ok": "59472",
        "ko": "60007"
    },
    "group1": {
    "name": "t < 1000 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "1000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 38,
    "percentage": 63
},
    "group4": {
    "name": "failed",
    "count": 22,
    "percentage": 37
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.243",
        "ok": "0.154",
        "ko": "0.089"
    }
},
contents: {
"req_jaxb-v0-request-c7929": {
        type: "REQUEST",
        name: "jaxb-v0-request spring",
path: "jaxb-v0-request spring",
pathFormatted: "req_jaxb-v0-request-c7929",
stats: {
    "name": "jaxb-v0-request spring",
    "numberOfRequests": {
        "total": "15",
        "ok": "8",
        "ko": "7"
    },
    "minResponseTime": {
        "total": "55666",
        "ok": "55666",
        "ko": "60000"
    },
    "maxResponseTime": {
        "total": "60005",
        "ok": "59695",
        "ko": "60005"
    },
    "meanResponseTime": {
        "total": "58616",
        "ok": "57403",
        "ko": "60002"
    },
    "standardDeviation": {
        "total": "1679",
        "ok": "1459",
        "ko": "2"
    },
    "percentiles1": {
        "total": "59695",
        "ok": "56910",
        "ko": "60002"
    },
    "percentiles2": {
        "total": "60002",
        "ok": "58824",
        "ko": "60004"
    },
    "percentiles3": {
        "total": "60004",
        "ok": "59484",
        "ko": "60005"
    },
    "percentiles4": {
        "total": "60005",
        "ok": "59653",
        "ko": "60005"
    },
    "group1": {
    "name": "t < 1000 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "1000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 8,
    "percentage": 53
},
    "group4": {
    "name": "failed",
    "count": 7,
    "percentage": 47
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.061",
        "ok": "0.032",
        "ko": "0.028"
    }
}
    },"req_jaxb-v1-request-a8b23": {
        type: "REQUEST",
        name: "jaxb-v1-request javax",
path: "jaxb-v1-request javax",
pathFormatted: "req_jaxb-v1-request-a8b23",
stats: {
    "name": "jaxb-v1-request javax",
    "numberOfRequests": {
        "total": "15",
        "ok": "0",
        "ko": "15"
    },
    "minResponseTime": {
        "total": "60001",
        "ok": "-",
        "ko": "60001"
    },
    "maxResponseTime": {
        "total": "60008",
        "ok": "-",
        "ko": "60008"
    },
    "meanResponseTime": {
        "total": "60003",
        "ok": "-",
        "ko": "60003"
    },
    "standardDeviation": {
        "total": "2",
        "ok": "-",
        "ko": "2"
    },
    "percentiles1": {
        "total": "60002",
        "ok": "-",
        "ko": "60002"
    },
    "percentiles2": {
        "total": "60004",
        "ok": "-",
        "ko": "60004"
    },
    "percentiles3": {
        "total": "60006",
        "ok": "-",
        "ko": "60006"
    },
    "percentiles4": {
        "total": "60008",
        "ok": "-",
        "ko": "60008"
    },
    "group1": {
    "name": "t < 1000 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "1000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 15,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.061",
        "ok": "-",
        "ko": "0.061"
    }
}
    },"req_jaxb-v3-request-69b46": {
        type: "REQUEST",
        name: "jaxb-v3-request compas",
path: "jaxb-v3-request compas",
pathFormatted: "req_jaxb-v3-request-69b46",
stats: {
    "name": "jaxb-v3-request compas",
    "numberOfRequests": {
        "total": "15",
        "ok": "15",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "57241",
        "ok": "57241",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "58764",
        "ok": "58764",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "58036",
        "ok": "58036",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "472",
        "ok": "472",
        "ko": "-"
    },
    "percentiles1": {
        "total": "57987",
        "ok": "57987",
        "ko": "-"
    },
    "percentiles2": {
        "total": "58431",
        "ok": "58431",
        "ko": "-"
    },
    "percentiles3": {
        "total": "58734",
        "ok": "58734",
        "ko": "-"
    },
    "percentiles4": {
        "total": "58758",
        "ok": "58758",
        "ko": "-"
    },
    "group1": {
    "name": "t < 1000 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "1000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 15,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.061",
        "ok": "0.061",
        "ko": "-"
    }
}
    },"req_jaxb-v4-request-9db4c": {
        type: "REQUEST",
        name: "jaxb-v4-request jakarta",
path: "jaxb-v4-request jakarta",
pathFormatted: "req_jaxb-v4-request-9db4c",
stats: {
    "name": "jaxb-v4-request jakarta",
    "numberOfRequests": {
        "total": "15",
        "ok": "15",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "54962",
        "ok": "54962",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "58999",
        "ok": "58999",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "57495",
        "ok": "57495",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "1330",
        "ok": "1330",
        "ko": "-"
    },
    "percentiles1": {
        "total": "57629",
        "ok": "57629",
        "ko": "-"
    },
    "percentiles2": {
        "total": "58795",
        "ok": "58795",
        "ko": "-"
    },
    "percentiles3": {
        "total": "58977",
        "ok": "58977",
        "ko": "-"
    },
    "percentiles4": {
        "total": "58995",
        "ok": "58995",
        "ko": "-"
    },
    "group1": {
    "name": "t < 1000 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "1000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 15,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.061",
        "ok": "0.061",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
