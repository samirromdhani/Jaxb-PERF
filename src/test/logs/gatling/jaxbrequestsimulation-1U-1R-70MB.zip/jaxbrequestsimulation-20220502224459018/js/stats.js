var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "4",
        "ok": "4",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "21798",
        "ok": "21798",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "28545",
        "ok": "28545",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "24145",
        "ok": "24145",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "2606",
        "ok": "2606",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23118",
        "ok": "23118",
        "ko": "-"
    },
    "percentiles2": {
        "total": "24696",
        "ok": "24696",
        "ko": "-"
    },
    "percentiles3": {
        "total": "27775",
        "ok": "27775",
        "ko": "-"
    },
    "percentiles4": {
        "total": "28391",
        "ok": "28391",
        "ko": "-"
    },
    "group1": {
    "name": "t < 1000 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "1000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 4,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.041",
        "ok": "0.041",
        "ko": "-"
    }
},
contents: {
"req_jaxb-v0-request-c7929": {
        type: "REQUEST",
        name: "jaxb-v0-request spring",
path: "jaxb-v0-request spring",
pathFormatted: "req_jaxb-v0-request-c7929",
stats: {
    "name": "jaxb-v0-request spring",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "28545",
        "ok": "28545",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "28545",
        "ok": "28545",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "28545",
        "ok": "28545",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "28545",
        "ok": "28545",
        "ko": "-"
    },
    "percentiles2": {
        "total": "28545",
        "ok": "28545",
        "ko": "-"
    },
    "percentiles3": {
        "total": "28545",
        "ok": "28545",
        "ko": "-"
    },
    "percentiles4": {
        "total": "28545",
        "ok": "28545",
        "ko": "-"
    },
    "group1": {
    "name": "t < 1000 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "1000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 1,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.01",
        "ok": "0.01",
        "ko": "-"
    }
}
    },"req_jaxb-v1-request-a8b23": {
        type: "REQUEST",
        name: "jaxb-v1-request javax",
path: "jaxb-v1-request javax",
pathFormatted: "req_jaxb-v1-request-a8b23",
stats: {
    "name": "jaxb-v1-request javax",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "23413",
        "ok": "23413",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "23413",
        "ok": "23413",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "23413",
        "ok": "23413",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "23413",
        "ok": "23413",
        "ko": "-"
    },
    "percentiles2": {
        "total": "23413",
        "ok": "23413",
        "ko": "-"
    },
    "percentiles3": {
        "total": "23413",
        "ok": "23413",
        "ko": "-"
    },
    "percentiles4": {
        "total": "23413",
        "ok": "23413",
        "ko": "-"
    },
    "group1": {
    "name": "t < 1000 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "1000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 1,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.01",
        "ok": "0.01",
        "ko": "-"
    }
}
    },"req_jaxb-v3-request-69b46": {
        type: "REQUEST",
        name: "jaxb-v3-request compas",
path: "jaxb-v3-request compas",
pathFormatted: "req_jaxb-v3-request-69b46",
stats: {
    "name": "jaxb-v3-request compas",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "22822",
        "ok": "22822",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "22822",
        "ok": "22822",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "22822",
        "ok": "22822",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "22822",
        "ok": "22822",
        "ko": "-"
    },
    "percentiles2": {
        "total": "22822",
        "ok": "22822",
        "ko": "-"
    },
    "percentiles3": {
        "total": "22822",
        "ok": "22822",
        "ko": "-"
    },
    "percentiles4": {
        "total": "22822",
        "ok": "22822",
        "ko": "-"
    },
    "group1": {
    "name": "t < 1000 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "1000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 1,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.01",
        "ok": "0.01",
        "ko": "-"
    }
}
    },"req_jaxb-v4-request-9db4c": {
        type: "REQUEST",
        name: "jaxb-v4-request jakarta",
path: "jaxb-v4-request jakarta",
pathFormatted: "req_jaxb-v4-request-9db4c",
stats: {
    "name": "jaxb-v4-request jakarta",
    "numberOfRequests": {
        "total": "1",
        "ok": "1",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "21798",
        "ok": "21798",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "21798",
        "ok": "21798",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "21798",
        "ok": "21798",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "0",
        "ok": "0",
        "ko": "-"
    },
    "percentiles1": {
        "total": "21798",
        "ok": "21798",
        "ko": "-"
    },
    "percentiles2": {
        "total": "21798",
        "ok": "21798",
        "ko": "-"
    },
    "percentiles3": {
        "total": "21798",
        "ok": "21798",
        "ko": "-"
    },
    "percentiles4": {
        "total": "21798",
        "ok": "21798",
        "ko": "-"
    },
    "group1": {
    "name": "t < 1000 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "1000 ms < t < 3000 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 3000 ms",
    "count": 1,
    "percentage": 100
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "0.01",
        "ok": "0.01",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
